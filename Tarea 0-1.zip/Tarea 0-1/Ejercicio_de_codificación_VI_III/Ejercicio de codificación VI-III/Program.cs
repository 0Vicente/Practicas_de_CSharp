﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_VI_III
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] vector = new string[3];

            Console.WriteLine("===============>>> VECTOR <<<=================\n");
            for (int i = 0; i <= 2; i++)
            {
                if (i == 3)
                {
                    break;
                }

                Console.WriteLine("Ingrese el nombre del vector " + i);
                vector[i] = Console.ReadLine();
            }

            for (int j = 0; j < vector.Length; j++)
            {
                Console.WriteLine("Valor del vector " + j + " = " + vector[j]);
            }

            Console.ReadKey();
        }
    }
}
