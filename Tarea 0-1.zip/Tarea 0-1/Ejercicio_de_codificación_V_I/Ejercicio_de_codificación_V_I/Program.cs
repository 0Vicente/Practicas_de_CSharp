﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_V_I
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===============>>> TABLA DEL 4 <<<=================");
            int numero = 1;
            while (numero <=12)
            {
                Console.WriteLine("4X" + numero + "=" + (4 * numero));
                numero++;
            }

            Console.ReadKey();
        }
    }
}
