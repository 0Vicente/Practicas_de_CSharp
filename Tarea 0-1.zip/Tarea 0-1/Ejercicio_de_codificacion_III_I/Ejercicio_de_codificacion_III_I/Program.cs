﻿using System;

namespace Ejercicio_de_codificacion_III_I
{
    class Program
    {
        static void Main(string[] args)
        {
            double SB, SN, TH, HT, DD;

            Console.WriteLine("===============>>> CALCULO DE SUELDO <<<=================");
            Console.WriteLine("\nIngrese la cantidad de horas trabajadas del Empleado: ");
            HT = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la tarifa de las horas trabajadas del Empleado: ");
            TH = int.Parse(Console.ReadLine());

            SB = HT * TH;

            if (SB > 5000)
            {
                DD = SB * 0.1;
            }
            else
            {
                DD = SB * 0.05;
            }
            
            SN = SB - DD;

            Console.WriteLine("\nSUELDO BRUTO: RD$" + SB + "\nDESCUENTOS: RD$" + DD + "\nSUELDO NETO: RD$" + SN);
            Console.ReadKey();
        }
    }
}
