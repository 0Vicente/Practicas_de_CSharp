﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_II_II
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===============>>> CALCULO DE PROMEDIO <<<=================");
            double notaE = 0, notaF = 0, notaM = 0, notaA = 0, promedio = 0;
            Console.WriteLine("\nIngrese la nota  de Enero: ");
            notaE = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la nota  de Febrero: ");
            notaF = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la nota  de Marzo: ");
            notaM = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la nota  de Abril: ");
            notaA = double.Parse(Console.ReadLine());

            promedio = (notaE + notaF + notaM + notaA) / 4;

            Console.WriteLine("\nNota promedio final: "+promedio);

            if (promedio <70)
            {
                Console.WriteLine("\nREPROBADO");
            }
            else
            {
                Console.WriteLine("\nAPROBADO");
            }

            Console.ReadKey();
        }
    }
}
