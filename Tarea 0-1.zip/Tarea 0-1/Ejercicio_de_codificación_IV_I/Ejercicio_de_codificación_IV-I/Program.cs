﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_IV_I
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("===============>>> NUMEROS DEL 1 AL 100 <<<=================");
            
            for (int i = 1; i <= 100; i++)
            {
                Console.WriteLine(i);
            }

            Console.ReadKey();
        }
    }
}
