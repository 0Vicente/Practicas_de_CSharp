﻿using System;

namespace Ejercicio_de_codificacion_II_III
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===============>>> Calculo de Itbis <<<=================");
            double itbis = 0, precio = 0, resultado = 0;

            Console.WriteLine("\nIngrese el precio del producto: ");
            precio = double.Parse(Console.ReadLine());

            itbis = precio * 0.18;
            resultado = precio + itbis;

            Console.WriteLine("\nEl Precio del Producto es: RD$" + precio + "\nItbis: RD$" + itbis + "\nTotal: RD$" + resultado);
            Console.ReadKey();
        }
    }
}
