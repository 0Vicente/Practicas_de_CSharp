﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_VI_IV
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[4] { 70, 60, 80, 70 };
            int[] b = new int[4] { 68, 90, 80, 70 };

            Console.WriteLine("===============>>> SUMA VECTORES <<<=================\n");
            for (int i = 0; i<2; i++)
            {
                for (int j = 0; j<2; j++)
                {
                    int result = a[i] + b[j];
                    Console.WriteLine("Suma de vectores: " + result);
                }
            }


            Console.ReadKey();
        }
    }
}
