﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_VI_I
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("===============>>> VECTOR DE 4 LUGARES <<<=================");
            int[] vector = new int[4];
            int r;
            for (int i = 0; i <= 4; i++)
            {
                if (i == 4)
                {
                    break;
                }

                r = i + 1;
                Console.WriteLine("Ingrese en valor de la posicion " + r +": ");
                vector[i] = int.Parse(Console.ReadLine());
            }
            int k;
            for (int j = 0; j < vector.Length; j++)
            {
                k = j + 1;
                Console.WriteLine("Valor de la posicion "+ k +" = "+ vector[j]);
            }

            Console.ReadKey();
        }
    }
}
