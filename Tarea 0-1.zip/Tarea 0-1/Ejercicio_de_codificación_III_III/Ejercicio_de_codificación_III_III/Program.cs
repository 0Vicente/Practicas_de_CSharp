﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_III_III
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===============>>> INFORMACION EDAD DE UNA PERSONA <<<=================");
            
            int edad = 0;
            string condicion;

            Console.WriteLine("\nIngrese su edad: ");
            edad = int.Parse(Console.ReadLine());

            condicion = "Aun nada";
            if (edad == 0 || edad == 1)
            {
                condicion = "Bebe";
            }
            else if (edad >= 2 && edad <= 12)
            {
                condicion = "Niño";
            }
            else if (edad >= 13 && edad <= 17)
            {
                condicion = "Adolecente";
            }
            else if (edad >= 18 && edad <= 30)
            {
                condicion = "Joven";
            }
            else if (edad >= 31 && edad <= 64)
            {
                condicion = "Adulto";
            }
            else if (edad >= 65 && edad <= 120)
            {
                condicion = "Anciano";
            }
            else if (edad <= 0 || edad >= 125)
            {
                condicion = "Error: esta edad no existe";
            }

            Console.WriteLine("\nSu edad es " + edad +" usted es un "+ condicion);
            Console.ReadKey();
        }
    }
}
