﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_IV_II
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("===============>>> NUMEROS DEL 100 AL 105 <<<=================");

            for (int i = 100; i <= 105; i++)
            {
                Console.WriteLine(i);
            }

            Console.ReadKey();
        }
    }
}
