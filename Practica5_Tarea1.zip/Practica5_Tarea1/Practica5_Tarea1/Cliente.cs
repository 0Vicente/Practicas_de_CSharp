﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica5_Tarea1
{
    public class Cliente :Persona
    {
        public decimal LimiteCredito
        {
            get; set;
        }

    }
}
