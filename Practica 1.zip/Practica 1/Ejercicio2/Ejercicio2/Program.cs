﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2_P1
{
    class Program
    {
        static void Main(string[] args)
        {
            double masa, presion, volumen, temperatura, resultado;
            string vpresion, vvolumen, vtemperatura;

            Console.WriteLine("En este Momento vamos a calcular la masa de aire \n\nIntroduzca la presion: ");
            vpresion = Console.ReadLine();
            presion = int.Parse(vpresion);
            Console.WriteLine("Introduzca el volumen: ");
            vvolumen = Console.ReadLine();
            volumen = int.Parse(vvolumen);
            Console.WriteLine("Introduzca la Temperatura: ");
            vtemperatura = Console.ReadLine();
            temperatura = int.Parse(vtemperatura);

            masa = (volumen * presion) / (0.37 * (temperatura + 460));
            resultado = Math.Round(masa, 2);

            Console.WriteLine("\nLa Masa del aire segun los parametros introducidos es: " + resultado);
            Console.ReadKey();

            Console.ReadKey();
        }
    }
}