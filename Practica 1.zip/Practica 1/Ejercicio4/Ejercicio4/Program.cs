﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4_P1
{
    class Program
    {
        static void Main(string[] args)
        {
            double pesos, dolar, dolares, resultado;
            string vpesos, vdolar;

            Console.WriteLine("Vamos a convertir el valor en pesos a dolares\n\nCual es es la cantidad en pesos: ");
            vpesos = Console.ReadLine();
            pesos = Convert.ToDouble(vpesos);
            Console.WriteLine("Cual es el valor del dolar actual: ");
            vdolar = Console.ReadLine();
            dolar = double.Parse(vdolar);
            Console.WriteLine("valor dolar: " + dolar);
            dolares = pesos / dolar;
            resultado = Math.Round(dolares, 2);
            Console.WriteLine("\nRD$" + vpesos + " en dolares es: US$" + resultado);
            Console.ReadKey();
        }
    }
}