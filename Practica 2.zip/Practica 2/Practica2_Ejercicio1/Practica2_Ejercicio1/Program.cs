﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1_p2
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero, multiplos, aumento = 1;
            string vnumero;

            Console.WriteLine("Vamos a calcular los multiplos menores de 200 de un numero\n\nIntroduzca el numero que desea encontrar los multiplos:");
            vnumero = Console.ReadLine();
            numero = int.Parse(vnumero);

            Console.WriteLine("\nLos Multiplos de " + vnumero + " son:");
            multiplos = 0;
            while (multiplos < 200)
            {
                multiplos = aumento * numero;
                Console.WriteLine(multiplos);
                aumento = aumento + 1;
            }

            Console.ReadKey();
        }

    }
}