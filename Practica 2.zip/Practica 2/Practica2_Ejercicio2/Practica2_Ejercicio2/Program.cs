﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2_P2
{
    class Program
    {
        static void Main(string[] args)
        {
            double sueldo, antiguedad, aumento, resultado;
            string vsueldo, vantiguedad;

            Console.WriteLine("Vamos a calcular el aumento de un empledo segun su sueldo y su antiguedad\n\nIntroduzca el sueldo actual del empleado: ");
            vsueldo = Console.ReadLine();
            sueldo = double.Parse(vsueldo);

            Console.WriteLine("Introduzca los años de antiguedad: ");
            vantiguedad = Console.ReadLine();
            antiguedad = double.Parse(vantiguedad);

            if (sueldo < 500)
            {
                if (antiguedad < 10)
                {
                    aumento = sueldo + (sueldo * 0.05);
                }
                else
                {
                    aumento = sueldo + (sueldo * 0.2);
                }
            }
            else
            {
                aumento = sueldo;
            }
            Console.WriteLine("\nSabiendo que para:\n\nUn empleado con un sueldo mayor a RD$500 no corresponde aumento\nUn empleado con menos de 10 años le corresponde un aumento de 5%\nUn empleado con mas de 10 años le correspopnde un aumento de 20%");

            Console.WriteLine("\nEl sueldo anterio era RD$" + sueldo + " el nuevo sueldo es RD$" + aumento);
            Console.ReadKey();

        }
    }
}