﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            int cantidad, posicion, j, negativos, positivos, pares, impares;
            string vcantidad, vposicion;

            Console.WriteLine("Vamos a clasificar los numeros\n\nIntroduzaca la cantidad de numeros a clasificar: ");
            vcantidad = Console.ReadLine();
            cantidad = int.Parse(vcantidad);
            int[] arreglo = new int[cantidad];

            Console.WriteLine("\nIntruduce los numeros: \n");
            for (int i = 0; i < cantidad; i++)
            {
                j = i + 1;
                Console.WriteLine("Introduce el numero " + j);
                vposicion = Console.ReadLine();
                posicion = int.Parse(vposicion);
                arreglo[i] = posicion;
            }

            Console.WriteLine("\nLos numeros son: ");

            for (int i = 0; i < cantidad; i++)
            {
                j = i + 1;
                Console.WriteLine("Numero " + j + ": " + arreglo[i]);

            }
            positivos = 0;
            negativos = 0;
            pares = 0;
            impares = 0;
            for (int i = 0; i < cantidad; i++)
            {
                if (arreglo[i] < 0)
                {
                    negativos = negativos + 1;
                }
                else
                {
                    positivos = positivos + 1;
                }

                if (arreglo[i] % 2 == 0)
                {
                    pares = pares + 1;

                }
                else
                {
                    impares = impares + 1;
                }

            }
            Console.WriteLine("\nLa Clasificacion es la siguiente: \nLa cantidad de numeros pares es: " + pares + "\nLa cantidad de numeros impares es: " + impares + "\nLa cantidad de numeros positivos es: " + positivos + "\nLa cantidad de numeros negativos es: " + negativos);


            Console.ReadKey();
        }
    }
}