﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PruebaConstructor3
{
    class Empleado
    {
        double sueldo;
        string nombre, vsueldo;


        public void IntroducirDatosEmpleado()
        {
            Console.Write("Ingrese el nombre del empleado: ");
            nombre = Console.ReadLine();
            Console.Write("Ingrese el sueldo: ");
            vsueldo = Console.ReadLine();
            sueldo = double.Parse(vsueldo);

        }
        public void MostrarDatosEmpleado()
        {

            Console.Write("\nLos datos del empleado son:");
            Console.Write("\nNombre: " + nombre + "\nSueldo: RD$" + sueldo);

        }
        public void PagaImpuestos()
        {
            if (sueldo > 3000)
            {
                Console.Write("\n\nDebe pagar impuestos");
            }
            else
            {
                Console.Write("\n\nNo debe pagar impuestos");
            }
            Console.ReadKey();
        }




        static void Main(string[] args)
        {

            Console.Write("Vamos a obterner y mostrar los datos de un empleado\n\n");
            Empleado empleado1;
            empleado1 = new Empleado();
            empleado1.IntroducirDatosEmpleado();
            empleado1.MostrarDatosEmpleado();
            empleado1.PagaImpuestos();
            Console.ReadKey();

        }
    }
}