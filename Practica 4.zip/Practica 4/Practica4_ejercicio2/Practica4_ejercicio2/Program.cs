﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2P4
{
    class Punto
    {
        int x, y;
        string vx, vy;

        public void IntroducirDatosPunto()
        {

            Console.Write("Ingrese coordenada x: ");
            vx = Console.ReadLine();
            x = int.Parse(vx);
            Console.Write("Ingrese coordenada y: ");
            vy = Console.ReadLine();
            y = int.Parse(vy);
        }

        void LocalizarPunto()
        {
            if (x > 0 && y > 0)
            {
                Console.Write("El punto esta en el primer cuadrante");
            }
            else
            {
                if (x < 0 && y > 0)
                {
                    Console.Write("El punto esta en el segundo cuadrante");
                }
                else
                {
                    if (x < 0 && y < 0)
                    {
                        Console.Write("El punto esta en el tercer cuadrante");
                    }
                    else
                    {
                        if (x > 0 && y < 0)
                        {
                            Console.Write("El punto esta en el cuarto cuadrante");
                        }
                        else
                        {
                            Console.Write("El punto no está en un cuadrante");
                        }
                    }
                }
            }
            Console.ReadKey();
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Vamos a Localizar un punto en el Plano\n");
            Punto punto1 = new Punto();
            punto1.IntroducirDatosPunto();
            punto1.LocalizarPunto();
        }
    }
}