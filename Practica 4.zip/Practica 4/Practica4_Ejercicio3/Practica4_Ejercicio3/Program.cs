﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3_P4
{
    class Socio
    {
        private string nombre;
        private int antiguedad;

        public string Nombre
        {
            set
            {
                nombre = value;
            }
            get
            {
                return nombre;
            }
        }

        public int Antiguedad
        {
            set
            {
                if (value >= 0)
                {
                    antiguedad = value;
                }
                else
                {
                    Console.Write("No se puede asignar aun valor negativo a la antiguedad");
                }
            }
            get
            {
                return antiguedad;
            }
        }
    }


    class Club
    {
        private Socio socio1, socio2, socio3;

        public Club()
        {
            int antiguedad;
            string nombre, vantiguendad;
            socio1 = new Socio();
            Console.WriteLine("\nIntroduzca el nombre del Socio1: ");
            nombre = Console.ReadLine();
            socio1.Nombre = nombre;
            Console.WriteLine("Introduzca el tiempo del Socio1: ");
            vantiguendad = Console.ReadLine();
            antiguedad = int.Parse(vantiguendad);
            socio1.Antiguedad = antiguedad;

            socio2 = new Socio();
            Console.WriteLine("\nIntroduzca el nombre del Socio2: ");
            nombre = Console.ReadLine();
            socio2.Nombre = nombre;
            Console.WriteLine("Introduzca el tiempo del Socio2: ");
            vantiguendad = Console.ReadLine();
            antiguedad = int.Parse(vantiguendad);
            socio2.Antiguedad = antiguedad;

            socio3 = new Socio();
            Console.WriteLine("\nIntroduzca el nombre del Socio3: ");
            nombre = Console.ReadLine();
            socio3.Nombre = nombre;
            Console.WriteLine("Introduzca el tiempo del Socio3: ");
            vantiguendad = Console.ReadLine();
            antiguedad = int.Parse(vantiguendad);
            socio3.Antiguedad = antiguedad;
        }

        public void MostrarSocio()
        {

            Console.WriteLine("\nLos datos de los Socios son:\n");
            Console.WriteLine("Socio1: \nNombre: " + socio1.Nombre + "\nAntiguedad: " + socio1.Antiguedad);
            Console.WriteLine("\nSocio2: \nNombre: " + socio2.Nombre + "\nAntiguedad: " + socio2.Antiguedad);
            Console.WriteLine("\nSocio3: \nNombre: " + socio3.Nombre + "\nAntiguedad: " + socio3.Antiguedad);
        }

        public void MayorAntiguedad()
        {
            if (socio1.Antiguedad > socio2.Antiguedad &&
                socio1.Antiguedad > socio3.Antiguedad)
            {
                Console.WriteLine("\nSocio com mayor antiguedad:" + socio1.Nombre);
            }
            else
            {
                if (socio2.Antiguedad > socio3.Antiguedad)
                {
                    Console.WriteLine("\nSocio com mayor antiguedad:" + socio2.Nombre);
                }
                else
                {
                    Console.WriteLine("\nSocio com mayor antiguedad:" + socio3.Nombre);
                }
            }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Vamos a Verificar cual es el socio con mas tiempo en el Club\n\n");
            Club club1 = new Club();
            club1.MostrarSocio();
            club1.MayorAntiguedad();
            Console.ReadKey();
        }
    }
}